package a8;


import java.util.*;

public class PasswordManager<K, V> implements Map<K, V> {
    private static final String ANY_STRING_OF_YOUR_CHOOSING = "YOUR PASSWORD HERE";
    private static final String MASTER_PASSWORD = "1234";
    private Account[] _passwords;
    private static final int HASH_SIZE = 50;

    public PasswordManager() {
        _passwords = new Account[HASH_SIZE];
    }


    // TODO: put

    /**
     * Creates an Account object using the key value pair,
     * and inserts the object at the appropriate index
     * based on the hash of they key. If the key already
     * exists in map, update its value.
     *
     * @param key:   the website name
     * @param value: the password
     */
    @Override
    public void put(K key, V value) {
        int hashIndex = getHashCode(key);
        Account<K, V> keyValue = new Account<K, V>(key, value);
        Account<K, V> existing = _passwords[hashIndex];
        if (existing == null) {
            _passwords[hashIndex] = keyValue;
        } else {
            while (existing != null) {
                if (existing.getWebsite().equals(key)) {
                    existing.setPassword(value);
                    return;
                }
                if (existing.getNext() == null) {
                    existing.setNext(keyValue);
                    return;
                }
                existing = existing.getNext();
            }
        }
    }

    // TODO: get

    /**
     * Returns the value associated with the given key.
     * This operation should have O(1) runtime.
     * If the key is not in the array, return null.
     *
     * @param key
     * @return the value (password) associated with that key
     */
    @Override
    public V get(K key) {
        int hashIndex = getHashCode(key);
        if (_passwords[hashIndex] == null) {
            return null;
        }
        Account<K, V> current = _passwords[hashIndex];
        while (current != null) {
            if (current.getWebsite() == key) {
                return (V) current.getPassword();
            }
            current = current.getNext();

        }
        return null;
    }

    // TODO: size

    /**
     * Returns the number of key-value mappings in the map.
     *
     * @return the number of accounts in the map.
     */
    @Override
    public int size() {
        int sizeOf = 0;
        for (int i = 0; i < _passwords.length; i++) {
            Account<K, V> current = _passwords[i];
            while (current != null) {
                sizeOf++;
                current = current.getNext();
            }
        }
        return sizeOf;
    }

    // TODO: keySet
    //

    /**
     * Returns a Set of all the keys (websites) contained in this map.
     *
     * @return A set of the keys contained in the map
     */
    @Override
    public Set<K> keySet() {
        Set<K> setOf = new HashSet<K>();
        for (int i = 0; i < _passwords.length; i++) {
            Account<K, V> current = _passwords[i];
            while (current != null) {
                setOf.add((K) current.getWebsite());
                current = current.getNext();
            }
        }
        return setOf;
    }


    // TODO: remove

    /**
     * Removes the Key and value pair from the map
     * and returns the removed value.
     * If the key is not in the array, return null.
     *
     * @param key to be removed
     * @return the value (password) that was removed
     */
    @Override
    public V remove(K key) {
        int hashIndex = getHashCode(key);
        Account<K, V> current = _passwords[hashIndex];
        if (current == null) {
            return null;
        }
        if (current.getWebsite().equals(key)) {
            _passwords[hashIndex] = current.getNext();
            return current.getPassword();
        }
        while (current != null) {
            Account<K, V> next = current.getNext();
            if (next.getWebsite().equals(key)) {
                current.setNext(next.getNext());
                return next.getPassword();
            }
            current = next;
        }
        return null;
    }
    // TODO: checkDuplicate

    /**
     * Returns a list the website names
     * that have a password matching the parameter
     *
     * @return A List containing the keys of accounts whose password
     * match the parameter
     */
    @Override
    public List<K> checkDuplicate(V value) {
        List<K> checkIf = new ArrayList<K>();
        for (int i = 0; i < _passwords.length; i++) {
            Account<K, V> current = _passwords[i];
            while (current != null) {
                if (current.getPassword().equals(value)) {
                    checkIf.add((K) current.getWebsite());
                }
                current = current.getNext();
            }
        }
        return checkIf;
    }


    // TODO: checkMasterPassword

    /**
     * Checks to see if the entered Master Password matches
     * the password stored in MASTER_PASSWORD
     *
     * @param enteredPassword - the password the user typed in
     * @return true if passwords match, false otherwise
     */
    @Override
    public boolean checkMasterPassword(String enteredPassword) {
        if (MASTER_PASSWORD.equals(enteredPassword)) {
            return true;
        } else {
            return false;
        }
    }

    /*
    Generates random password of input length
     */
    @Override
    public String generateRandomPassword(int length) {
        int leftLimit = 48; // numeral '0'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = length;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }

    /*
    Used for testing, do not change
     */
    public Account[] getPasswords() {
        return _passwords;
    }

    public int getHashCode(K key) {
        return Math.abs(key.hashCode()) % HASH_SIZE;
    }
}
