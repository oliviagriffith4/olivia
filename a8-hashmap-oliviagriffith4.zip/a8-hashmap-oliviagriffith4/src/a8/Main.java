package a8;


import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       Map<String, String> passwordManager = new PasswordManager<>();
        System.out.print("Enter Master Password: ");
        String input = scanner.next();
        //passwordManager.checkMasterPassword(input);
        while (!passwordManager.checkMasterPassword(input)) {
            System.out.print("Enter Master Password: ");
            input = scanner.next();
        }
        input = "";
        while (!input.equals("exit")) {
            System.out.print("Enter a Command: ");
            input = scanner.next().toLowerCase();
            String newPassword;
            String websiteName;
            if (!input.equals("exit")) {
                if (input.equals("new password")) {
                    System.out.print("Website Name: ");
                    websiteName = scanner.next();
                    System.out.print("Password: ");
                    newPassword = scanner.next();
                    passwordManager.put(websiteName, newPassword);
                }
                if (input.equals("get password")) {
                    System.out.print("Website Name: ");
                    websiteName = scanner.next();
                        System.out.print("Password does not exist");
                    } else {
                        System.out.print("the account's password");
                    }

                }
                System.out.println(passwordManager.size());

            }
        }
    }


