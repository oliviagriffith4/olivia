import { testNumber } from "./test-util";
import { print } from "introcs";

/*
 *
 * Author: Olivia Griffith
 *
 * ONYEN:Livg
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received
 * or given in the completion of this work. I certify that I understand and
 * could now rewrite on my own, without assistance from course staff,
 * the problem set code I am submitting.
 */
export let count = (a: number[], b: number): number => {
    let n = 0;
    for (let i = 0; i < a.length; i++) {
        if (a[i] === b) {
            n++;
        }
    }
    return n;
};

// max function
export let max = (a: number[]): number => {
    let b = 0;
    if (a.length === 0) {
        return Number.MIN_VALUE;
    } else {
        for (let i = 0; i < a.length; i++) {
            if (a[i] > a[b]) {
                b = i;
            }
        }
    }
    return a[b];
};
// has function
export let has = (a: number[], b: number): boolean => {
    let c = true;
    if (a.length === 0) {
        return false;
    } else {
        for (let i = 0; i < a.length; i++) {
            if (a[i] === b) {
                return true;
            }
        }
        return false;
    }
    return c;
};
export let all = (a: number[], b: number): boolean => {
    if (a.length === 0) {
        return false;
    } else {
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b) {
                return false;
            }
        }
        return true;
    }

};
export let equals = (a: number[], b: number[]): boolean => {
    if (a.length !== b.length) {
        return false;
    } else {
        for (let i = 0; i < a.length; i++) {
            if (a[i] !== b[i]) {
                return false;
            }
        }

        return true;
    }
};
// a = upper bound, b = amount of numbers
export let cycle = (a: number, b: number): number[] => {
    if (a <= 0 || b <= 0) {
        return [];
    } else {
        let output = [];
        for (let i = 0; i < b; i++) {
            output[output.length] = i % a + 1;
        }
        return output;
    }
};
// concat
export let concat = (a: number[], b: number[]): number[] => {
    let output = [];
    for (let i = 0; i < a.length; i++) {
        output[output.length] = a[i];
    }
    for (let i = 0; i < b.length; i++) {
        output[output.length] = b[i];
    }
    return output;
};
// sub
export let sub = (a: number[], b: number, c: number): number[] => {
    let output = [];
    if (b < 0) {
        b = 0;
    }
    if (c > a.length) {
        c = a.length;
    }
    for (let i = b; i < c; i++) {
        output[output.length] = a[i];
    }
    return output;
};
// splice
export let splice = (a: number[], b: number, c: number[]): number[] => {
    if (b <= 0) {
        return concat(c, a);
    } else if (b > a.length) {
        return concat(a, c);
    } else {
        let output: number[] = [];
        for (let i = 0; i < a.length; i++) {
            if (i === b) {
                for (let n = 0; n < c.length; n++) {
                    output[output.length] = c[n];
                }
            }
            output[output.length] = a[i];
        }
        return output;
    }
};
