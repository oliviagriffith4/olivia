/*
 *
 * Author: Olivia Griffith
 *
 * ONYEN:Livg
 *
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received
 * or given in the completion of this work. I certify that I understand and
 * could now rewrite on my own, without assistance from course staff,
 * the problem set code I am submitting.
 */

/** Import Test Helpers */
import { testNumber, testBoolean, testArray } from "./test-util";

// TODO: Import functions as you write them
import { count, max, has, all, equals, cycle, concat, sub, splice } from "./array-utils";

export let main = async () => {

    // Part 1. count
    // Use Cases
    testNumber("count([10, 20], 20)", 1, count([10, 20], 20));
    testNumber("count([20, 20], 20)", 2, count([20, 20], 20));
    // Edge Cases
    testNumber("count([], 20)", 0, count([], 20));
    testNumber("count([10, 30], 20", 0, count([10, 30], 20));
    // Use Cases
    testNumber("max[10,20]", 20, max([10, 20]));
    testNumber("max[15,22]", 22, max([15, 22]));
    // Edge Cases
    testNumber("max[-12, -10, -11])", -10, max([-12, -10, -11]));
    // Use Cases
    testBoolean("has[3],1", false, has([3], 1));
    testBoolean("has [3], 2", false, has([3], 2));
    // Edge Cases
    testBoolean("has[],1", false, has([], 1));
    // Use Cases
    testBoolean("all[1], 1", true, all([], 1));
    testBoolean("all[2], 2", true, all([], 2));
    // Edge Cases
    testBoolean("all[], 5", true, all([], 5));
    // Use Cases
    testBoolean("equals([3], [1]", false, equals([3], [1]));
    testBoolean("equals([2], [1]", false, equals([2], [1]));
    // Edge Cases
    testBoolean("equals([], [1]", false, equals([], [1]));
    // Use Cases
    testArray("cycle[2, 2]", [1, 2], cycle(2, 2));
    testArray("cycle[3, 2]", [1, 2, 3], cycle(3, 3));
    // // Edge Cases
    testArray("cycle[0, 3]", [], cycle(0, 3));
    // // Use Cases
    testArray("concat([1, 2], [3, 4])", [1, 2, 3, 4], concat([1, 2], [3, 4]));
    testArray("concat([5, 6], [7, 8])", [5, 6, 7, 8], concat([5, 6], [7, 8]));
    // // Edge Cases
    testArray("concat([1],[])", [], concat([1], []));
    // // Use Cases
    testArray("sub([1], 1, 2]", [], sub([1], -1, 0));
    testArray("sub([4], 1, 2]", [], sub([4], -1, 0));
    // // Edge Cases 
    testArray("sub[1], -1, 0)", [], sub([1], -1, 0));
    // // Use Cases
    testArray("splice([1, 5], 0, []", [1, 5], splice([1, 5], 0, [5, 6]));
    testArray("splice([3, 4], 0, []", [3, 4], splice([3, 4], 0, [3, 4]));
    // // Edge Cases
    testArray("splice([4, 2], 0, []", [4, 2], splice([4 , 2], 0, []));
};

main();