package a5;


public class Main {
  public static void main(String[] args) {
    /*
    This is a basic example of how to create a BST and add values to it.
    You should add more examples and use this class to debug your code
    */
    BST<Integer> bst = new NonEmptyBST<Integer>(6);
    // bst.printPreOrderTraversal();

    bst = bst.insert(2);
    bst.printInOrderTraversal();
    System.out.println();
    bst = bst.insert(8);
    bst.printInOrderTraversal();
    System.out.println();
    bst = bst.insert(1);
    bst.printInOrderTraversal();
    System.out.println();
    bst = bst.insert(4);
    bst.printInOrderTraversal();
    System.out.println();
    bst = bst.insert(3);
    bst.printPostOrderTraversal();
    System.out.println();
  }
}
