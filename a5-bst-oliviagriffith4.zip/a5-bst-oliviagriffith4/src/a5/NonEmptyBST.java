package a5;
import java.util.LinkedList;
import java.util.Queue;


public class NonEmptyBST<T extends Comparable<T>> implements BST<T> {
	private T _element;
	private BST<T> _left;
	private BST<T> _right;
	// private int _size;
	private Object NonEmptyBST;


	public NonEmptyBST(T element) {

		_left = new EmptyBST<>();
		_right = new EmptyBST<>();
		_element = element;
		// _size = 1;
	}


	// TODO: size
	@Override
	public int size() {
		if((_left.isEmpty()) && (_right.isEmpty())) {
			return 1;
		} else
			return 1 + _left.size() + _right.size();
	}

	// TODO: findMin
	@Override
	public T findMin() {
		NonEmptyBST current = this;
		if (_left.isEmpty())
			return _element;
		else
			return _left.findMin();
	}

	// TODO: findMax
	@Override
	public T findMax() {
		NonEmptyBST current = this;
		if (_right.isEmpty())
			return _element;
		else
			return _right.findMax();
	}

	// TODO: contains
	@Override
	public boolean contains(T element) {
			if (element.compareTo(_element) == 0) {
				return true;
			} else if (element.compareTo(_element) == -1) {
				return _left.contains(element);
			} else
				return _right.contains(element);
	}

	// TODO: insert
	@Override
	public BST<T> insert(T element) {

		// while (x != null) {
		if (element.compareTo(_element) == -1) {
			if (_left.isEmpty()) {
				_left = new NonEmptyBST<>(element);
				return this;
			} else
				_left = _left.insert(element);

		} else if ((element.compareTo(_element)) >= 0) {
			if (_right.isEmpty()) {
				_right = new NonEmptyBST<>(element);
				return this;
			} else
				_right = _right.insert(element);
		}
		return this;
	}

		 /* NonEmptyBST newnode = new NonEmptyBST<T>(element);
		NonEmptyBST x = this;
		NonEmptyBST y = null;
		_size++;
		if (element == null) {
			_element = (T) new NonEmptyBST<T>(element);
			return (BST<T>) _element;
		} else if (x != null) {
			if (element.compareTo(_element) <= 0) {
				if (x == null) {
					_left = new NonEmptyBST<T>(element);
				} else if (y != null)
					return insert(element);
			} else if (element.compareTo(_element) >= 0) {
				if (y == null) {
					_right = new NonEmptyBST<T>(element);
				} else
					return insert(element);
			}
		}
		return this;
	} /*




		/* If the tree is empty, return a new node
		/* if (_element == null) {
			_element = (T) new NonEmptyBST<T>(element);
			return (BST<T>) _element;

		}

			Otherwise, recur down the tree
			if (element.compareTo(_element) < 0) {
				this._left = insert(element);
			} else if (element.compareTo(_element) > 0)
				this._right = insert(element);

			return the (unchanged) node pointer
		return (BST<T>) _element;
	} /*



		/*	NonEmptyBST newnode = new NonEmptyBST<T>(element);
		NonEmptyBST x = this;
		NonEmptyBST y = null;
		_size++;

		while (x != null) {
			y = x;
			if (element.compareTo((T) x.getElement()) == -1) {
				x = (NonEmptyBST) x.getLeft();
				// x._left = insert(element);
			} else
				x = (NonEmptyBST) x.getRight();
			// x._right = insert(element);
		}
			if (y == null) {
				y = newnode;
			} else if ((element.compareTo((T) y.getElement()) == -1)) {
				// x._right = insert(getElement());
				y._left = newnode;
			} else
				y._right = newnode;
			return this;
	}
/*


		// If the root is null i.e the tree is empty
		// The new node is the root node
			/* if (element == null) {
				y = newnode;

				// If the new key is less then the leaf node key
				// Assign the new node to be its left child
			} else if (element.compareTo((T) y.getElement()) > 0) {
				y._left = newnode;

				// else assign the new node its right child
			} else
				y._right = newnode;

			// Returns the root
			return this;
		}*/


	// TODO: remove
	@Override
	// at the root node
	//if right then call right to remove on right tree
	//if left then call left to remove on right tree
	// right and left child
	//right or left child
	//or no child
	public BST<T> remove(T element) {
		NonEmptyBST curr = this;
		NonEmptyBST prev = null;


		if (element.compareTo(_element) == 1) {
			_right = _right.remove(element);
		} else if (element.compareTo(_element) == -1) {
			_left = _left.remove(element);
		} else if (element.compareTo(_element) == 0) {
			if ((_left.isEmpty()) && (_right.isEmpty())) {
				return new EmptyBST<>();
			}
			if (_left.isEmpty()) {
				return _right;
			}
			if (_right.isEmpty()) {
				return _left;
			}
			if ((!_left.isEmpty()) && (!_right.isEmpty())) {
				_element = _right.findMin();
				_right = _right.remove(_element);
			}
		}
		return this;
	}






	// return null;

	// TODO: printInOrderTraversal
	@Override
	public void printInOrderTraversal() {
		if (_element != null) {
			//Visit the node by Printing the node data
			// System.out.printf("%d ", getElement());
			if (getLeft() != null) {
				getLeft().printInOrderTraversal();
			}
			System.out.printf("%d ", getElement());
			if (getRight() != null) {
				getRight().printInOrderTraversal();
			}
		}
	}


	// TODO: printPreOrderTraversal
	@Override
	public void printPreOrderTraversal() {
		if (_element != null) {
			//Visit the node by Printing the node data
			System.out.printf("%d ", getElement());
			if (getLeft() != null) {
				getLeft().printPreOrderTraversal();
			}
			if (getRight() != null) {
				getRight().printPreOrderTraversal();
			}
		}
	}


	// TODO: printPostOrderTraversal
	@Override
	public void printPostOrderTraversal() {
		if (_element != null) {
			//Visit the node by Printing the node data

			if (getLeft() != null) {
				getLeft().printPostOrderTraversal();
			}
			if (getRight() != null) {
				getRight().printPostOrderTraversal();
			}
			System.out.printf("%d ", getElement());
		}
	}

	// TODO: printBreadthFirstTraversal
	@Override
	// NonEmptyBST<T> queue = new NonEmptyBST<T>(_element);
	public void printBreadthFirstTraversal() {
		Queue <BST> queue = new LinkedList();
		queue.add(this);
		while(!queue.isEmpty()){
			BST bsttree = queue.poll();
			if(!bsttree.isEmpty()) {
				System.out.print(bsttree.getElement() + " ");
			}
			if(!bsttree.getLeft().isEmpty()){
				queue.add(bsttree.getLeft());
			}
			if(!bsttree.getRight().isEmpty()){
				queue.add(bsttree.getRight());
			}
		}
	}





		/* NonEmptyBST<T> queue = new NonEmptyBST<T>(_element);
		if (_element == null)
			return;
		// queue.clear();
		queue.insert(_element);
		while (!queue.isEmpty()) {
			NonEmptyBST node = (NonEmptyBST) remove(queue._element);
			System.out.print(getElement() + " ");
			if (node.getLeft() != null) queue.insert((T) node.getLeft());
			if (node.getRight() != null) queue.insert((T) node.getRight());
		}
	} */
		/*
		NonEmptyBST x = this;
		if (_element == null)
			return;

		System.out.print(getElement()+ " ");
		printBreadthFirstTraversal((T) x.getLeft());
		printBreadthFirstTraversal((T) x.getRight());

	}*/



	@Override
	public int getHeight() {
		if ((getLeft() == null) && (getRight() == null)) {
				return 0;
		} else if (getLeft() == null) {
				return getRight().getHeight() + 1;
		} else if (getRight() == null) {
				return getLeft().getHeight() + 1;
		} else {
			return Math.max(_left.getHeight(), _right.getHeight())+1;
		}
	}



	@Override
	public BST<T> getLeft() {
		return _left;
	}

	@Override
	public BST<T> getRight() {
		return _right;
	}

	@Override
	public T getElement() {
		return _element;
	}

	@Override
	public boolean isEmpty() {
		return false;
	}


	private void clear() {
		_element = null;
	}
	}

