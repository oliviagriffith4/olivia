# A5-BST

Complete the implementation of NonEmptyBST.java. TODOs are put above every 
method to be implemented. Main.java includes an example of how to create a
BST and add values to it. 