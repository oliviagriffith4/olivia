package a4;



public class LinkedList<T> {
    private Node<T> head = null;
    private Node<T> tail = null;
    private int size = 0;


    /**
     * Remove the node at index i of the list.
     * Note that the first element is at index 0
     * If i is larger than the size of the list, throw an IndexOutOfBounds Exception
     *
     * ex: list: A -> B -> C -> D
     *     i: 1
     *     list after removeAtIndex: A -> C -> D
     *
     * @param i    - index of node to remove
     */
    public void removeAtIndex(int i) {
        if (i >= size()) {
            throw new IndexOutOfBoundsException("i is larger than the size of list");
        }
        Node<T> current = head; // the pointer to the  current list element
        int index = 0; // index of list and through the list of elements
        Node<T> prev = null;
        while (current != null) {
            if (index == i) {
                //remove(list.getValue());
                break;
            }
            prev = current;
            current = current.getNext();
            index++;
        }
         if(current == head){
           head = head.getNext();
            size--;
            return;
        }
        prev.setNext(current.getNext());
        if (current == tail) {
            tail = prev;
        }
        // if(current.getNext().getNext() == null) {
           // tail = current;
      //  }
       //  current.setNext(current.getNext().getNext());
        size--;
    }


    /**
     * Return true if this linked list is equal to the list argument, false otherwise.
     * Two lists are equal if they have the same size, and the same
     * elements in the same order.
     * ex:  list: 1 -> 4 -> 2
     *      list2: 1 -> 4 -> 2
     *      return: true
     *
     *      list: 1 -> 5
     *      list2: 2 -> 5
     *      return false;
     *
     * @param list2 - the list to merge into the current list
     * @return true if the lists have the same elements in the same order, false otherwise
     */
    public boolean isEqual(LinkedList list2) {
        if (size() != list2.size) {
            // System.out.println("different size");
            return false;
        }
        Node<T> list = list2.head;
        Node<T> list1 = head;
        while (list1 != null) {
            if (list1.getValue() != list.getValue()) {
               // System.out.println("different value");
                return false;
            }
            list1 = list1.getNext();
            list = list.getNext();
        }
        return true;
    }



    /**
     * Return true if the list is symmetrical, false otherwise
     * ex: list: 1 -> 2 -> 3 -> 2 -> 1
     *     return: true
     *
     *     list: a -> b -> c -> b -> f
     *     return: false
     *
     * @return true if the list is symmetrical, false otherwise
     */

    public boolean isSymmetrical() {
        boolean symmetrical = false;

        if (isEmpty()) {
            symmetrical = true;
        }
        // for (int i=0; i<size/2; i++) {
        LinkedList listcopy = new LinkedList<Integer>();
        Node<T> current = head;
        while (current != null) {
            listcopy.add(current.getValue());
            current = current.getNext();
        }
        // System.out.println(listcopy);
        listcopy.reverse();
        // System.out.println(listcopy);
        if (isEqual(listcopy)) {
            return true;
        } else
            return false;
    }

    /**
     * Stretch the list so that each element in the list is represented factor times
     * If the factor is 0 the list should be cleared (have 0 nodes)
     * ex: list: 1 -> 2 ->3
     *     factor: 3
     *     list after multiply: 1 -> 1 -> 1 -> 2 -> 2 -> 2 -> 3 -> 3 -> 3
     *
     * @param factor the amount to multiply the number of occurrences of each element by
     * @param
     */

    //clear
    //

    public void multiply(int factor) {
        LinkedList listmult = new LinkedList<Integer>();
        if (factor == 0) {
            clear();
        }
       //  LinkedList listcopy = new LinkedList<Integer>();
        Node<T> current = head;
        while (current != null) {
            for (int i = 0; i < factor; i++) {
                listmult.add(current.getValue());
            }
            current = current.getNext();

        }
        head = listmult.head;
        tail = listmult.tail;
        size = listmult.size;

    }

    /**
     * Given a sorted linked list, remove the duplicate values from the list
     * ex: list: 5 -> 6 -> 7 -> 7 -> 7 -> 8 -> 8 -> 9
     *     list after removeRepeats: 5 -> 6 -> 7 -> 8 -> 9
     *
     * @param
     */


    public void removeRepeats() {
        Node current = head;
        Node next = head.getNext();


        /* Traverse list till the last node */
        while (current.getNext() != null) {

                if (current.getValue().equals(next.getValue())) {
                    // current = next.getNext();
                    current.setNext(next.getNext());
                    next = current.getNext();
                } else {
                    current = next;
                    next = current.getNext();
                }
            }
        }
      // next = current.getNext();

            // compare current and next are equal to each other
            // remove the same values from the list
            // current.setnext = next.getNext; will remove same values
            //current = next; else
            //next = current.getnext;

            /*Set current node next to the next different
            element denoted by temp*/
           //  curr.getNext() = temp;



    /**
     * Reverse the list
     *
     * ex list:  10 -> 9 -> 8 -> 7
     *    list after reverse: 7 -> 8 -> 9 -> 10
     *
     */
    // create a new list
    // while size is greater than 0
    // want to add the tail element to the new list and remove the tail element
    // after while loop, set the head tail and size to be the new list
    public void reverse() {
        LinkedList listreverse = new LinkedList<Integer>();
        while (size > 0) {
            listreverse.add(tail.getValue());
            removeAtIndex(size - 1);
            System.out.println(listreverse);
           //  System.out.println("list reverse " + listreverse);
            // System.out.println("current list " + toString());
        }
        head = listreverse.head;
        tail = listreverse.tail;
        size = listreverse.size;

    }

    /**
     * Return true if the list contains a cycle, false otherwise
     * ex: list: 1 -> 2 -> 3 - > 4 --       (4 points to 2)
     *                ^              |
     *                |              |
     *                ---------------
     *      return: true
     *
     *      list: 1 -> 2 -> 3 -> 4
     *      return: false
     *
     * @return true if the list contains a cycle, false otherwise
     */
    public boolean containsCycle() {
        if(head == null) // list does not exist..so no loop either
            return false;

        Node slow, fast; // create two references.

        slow = fast = head; // make both refer to the start of the list

        while(true) {

            slow = slow.getNext();          // 1 hop

            if(fast.getNext() != null)
                fast = fast.getNext().getNext(); // 2 hops
            else
                return false;          // next node null => no loop

            if(slow == null || fast == null) // if either hits null..no loop
                return false;

            if(slow == fast) // if the two ever meet...we must have a loop
                return true;
        }
    }

    /**
     * Merge the given linked list into the current list. The 2 lists will always be
     * either the same size, or the current list will be longer than list2.
     * The examples below show how to handle each case.
     *
     * Note: Do NOT create and return a new list, merge the second list into the first one.
     *
     * ex: list: 1 -> 2 -> 3
     *     list2: 4 -> 5 -> 6
     *     return: 1 -> 4 -> 2 -> 5 -> 3 -> 6
     *
     *     list: 1 -> 2 -> 3 -> 4
     *     list2: 5 -> 6
     *     return 1 -> 5 -> 2 -> 6 -> 3 -> 4
     *
     * @param
     */
    public void merge(LinkedList list2) {
        Node<T> current = head;
        Node<T> list = list2.head;

        //  while (current != null) ;
        // insert every item in list2 into this list
        // using the add(int, element) method we already have
        // where index is determined by odd number ascending from 1, 3, 5, ...
        int oddNumber = 1;
        for (int i = 0; i < list2.size; i++) {
            add(oddNumber, list2.get(i));
            oddNumber += 2;
        }
            current = current.getNext();
        }



    /* Implementation given to you. Do not modify below this. */
    
    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void clear() {
        head = null;
        tail = null;
        size = 0;
    }

    public boolean contains(Object element) {
        Node<T> current = head;
        while(current != null) {
            if(current.getValue().equals(element)) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    public T[] toArray() {
        T[] arr =  (T[]) new Object[size()];
        Node<T> current = head;
        int i = 0;
        if(isEmpty()) {
            return arr;
        }
        while(current != null){
            arr[i] = current.getValue();
            current = current.getNext();
            i++;
        }
        return arr;
    }

    public void add(Object element) {
        Node<T> newNode = new NodeImpl<T>((T) element, null);
        if(isEmpty()) {
            head = newNode;
            tail = newNode;
            size++;
        } else {
            tail.setNext(newNode);
            tail = newNode;
            size++;
        }
    }

    public boolean remove(Object element) {
        Node<T> current = head;
        Node<T> prev = null;
        if(isEmpty()) {
            return false;
        }
        if(current.getValue() == element){
            head = head.getNext();
            size--;
            return true;
        }
        while(current.getNext().getValue() != element) {
            prev = current;
            current = current.getNext();
            if(current == null) {
                return false;
            }
        }
        prev.setNext(current.getNext());
        if (current == tail) {
            tail = prev;
        }
        // if(current.getNext().getNext() == null) {
           // tail = current;
       // }
       //  current.setNext(current.getNext().getNext());
        size--;
        return true;
    }

    public T get(int index) {
        validIndex(index);
        Node<T> current = head;
        int i = 0;
        while (i < index) {
            current = current.getNext();
            i++;
        }
        return current.getValue();
    }

    public T set(int index, Object element) {
        validIndex(index);
        Node<T> current = head;
        T prevValue = null;
        int i = 0;
        if(index == 0) {
            prevValue = head.getValue();
            head.setValue((T) element);
        } else {
            while(current != null) {
                if(i == index) {
                    prevValue = current.getValue();
                    current.setValue((T) element);
                    return prevValue;
                }
                current = current.getNext();
                i++;
            }
        }

        return prevValue;
    }

    public void add(int index, Object element) {
        if(index > size) {
            validIndex(index);
        }
        Node<T> current = head;
        int i = 0;
        if(index == 0) {
            if(isEmpty()) {
                add(element);
                return;
            } else {
                Node<T> newNode = new NodeImpl<T>((T) element, head.getNext());
                head = newNode;
                size++;
                return;
            }

        }  else if(index == size) {
            add(element);
            return;
        }
        while(current != null) {
            if(i == (index - 1)) {
                Node<T> temp = current.getNext();
                Node<T> newNode = new NodeImpl<T>((T) element, temp);
                current.setNext(newNode);
                size++;
                return;
            } else {
                current = current.getNext();
                i++;
            }
        }
    }

    public int indexOf(Object element) {
        Node<T> current = head;
        int index = 0;
        while(current != null) {
            if(current.getValue().equals((T) element)) {
                return index;
            }
            index++;
            current = current.getNext();
        }
        return -1;
    }

    public int lastIndexOf(Object element) {
        Node<T> current = head;
        int index = -1;
        int i = 0;
        while(current != null) {
            if(current.getValue().equals ((T) element)) {
                index = i;
            }
            i++;
            current = current.getNext();
        }
        return index;
    }

    public void validIndex(int i) {
        if(i < 0 || i >= size) {
            throw new IndexOutOfBoundsException("Invalid index");
        }
    }

    public Node<T> getHead() {
        return head;
    }

    @Override
    public String toString() {
        String list = "";
        Node<T> current = head;
        while(current != null) {
            if(current.getNext() == null)
                list+= current.getValue();
            else
                list += current.getValue() + " -> ";
            current = current.getNext();
        }
        return list;
    }


}
