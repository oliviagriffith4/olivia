package a4;


public class Main {

    public static void main(String[] args) {
        LinkedList list = new LinkedList<Integer>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(4);
        LinkedList list2 = new LinkedList<Integer>();
        list2.add(1);
        list2.add(4);
        list2.add(1);
        // list.removeAtIndex(0);
        // list.removeRepeats();
        // list.reverse();
        // list.multiply(3,list);
        // System.out.println(list.isSymmetrical());
        // list.merge(list);
       // System.out.println(list.containsCycle());
       //  list.deleteDuplicates(list.getHead());
        list.merge(list2);
        System.out.println(list.toString());
       //  System.out.println(list.isSymmetrical());
        // list.reverse();
       //  list.multiply(3,list);
        // list.isSymmetrical();

    }


    }

