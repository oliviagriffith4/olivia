declare let drawBoard: () => void;
export let model: number[][] = [];
export let p1Score: number = 0;
export let p0Score: number = 0;
export let winner: number = Number.NaN;
export let player: number = 0;


export let main = async () => {
    initModel();
    drawBoard();


};

export let initModel = (): void => {
    for (let row = 0; row < 2; row++) {
        model[row] = [];
        for (let col = 0; col < 6; col++) {
            model[row][col] = 4;
        }

    }
    return;
};

export let onClick = (row: number, col: number): boolean => {
    let stonesInHand: number = model[row][col];
    model[row][col] = 0;

    if (row === 0) {
        if (player === 1 || stonesInHand === 0) {
            model[row][col] = stonesInHand;
            return false;
        }
        let direction = -1;
        let goAgain = false;
        while (0 < stonesInHand) {
            col = col + direction;
            if (col === -1 && row === 0 ) {
                direction = 1;
                row = 1;
                p0Score++;
                if (stonesInHand === 1) {
                    goAgain = true;
                }
                stonesInHand = stonesInHand - 1;
            } else if (col === 6 && row === 1) {
                direction = -1;
                row = 0;
            } else if (model[row][col] === 0 && stonesInHand === 1 && row === 0) {
                p0Score = p0Score + model[1][col] + 1;
                model[1][col] = 0;
                stonesInHand = 0;
            } else {
                stonesInHand = stonesInHand - 1;
                model[row][col]++;
            }
        }
        if (goAgain) {
            player = 0;
        } else {
            player = 1;
        }
    } else if (row === 1) {
        if (player === 0 || stonesInHand === 0) {
            model[row][col] = stonesInHand;
            return false;
        }
        let direction = 1;
        let goAgain = false;
        while (0 < stonesInHand) {
            col = col + direction;
            if (col === 6 && row === 1) {
                direction = -1;
                row = 0;
                p1Score++;
                if (stonesInHand === 1) {
                    goAgain = true;
                }
                stonesInHand = stonesInHand - 1;
            } else if (col === -1 && row === 0) {
                direction = 1;
                row = 1;
            } else if (model[row][col] === 0 && stonesInHand === 1 && row === 1) {
                p1Score = p1Score + model[0][col] + 1;
                model[0][col] = 0;
                stonesInHand = 0;
            } else {
                stonesInHand = stonesInHand - 1;
                model[row][col]++;
            }
        }
        if (goAgain) {
            player = 1;
        } else {
            player = 0;
        }
    }
    checkIfGameOver();
    return true;
};
export let checkIfGameOver = (): void => {
    let sum0: number = sumRow(0);
    let sum1: number = sumRow(1);
    if (sum0 === 0 || sum1 === 0) {
        p0Score += sum0;
        p1Score += sum1;
        clearRow(0);
        clearRow(1);
        if (p0Score > p1Score) {
            winner = 0;
        } else if (p0Score < p1Score) {
            winner = 1;
        } else if (p0Score === p1Score) {
            winner = -1;
        }
    }
};



export let clearRow = (rows: number): void => {
    for (let row = 0; row < model.length; row++) {
        // model[row] = [];
        for (let col = 0; col < model[row].length; col++) {
            // model[row][col] = 0;
            if (row === rows) {
                model[row][col] = 0;
            }
        }

    }

    return;
};



export let sumRow = (rows: number): number => {
    let sum = 0;
    for (let row = 0; row < model.length; row++) {
        // model[row] = [];
        for (let col = 0; col < model[row].length; col++) {
            //model[row][col] = (row + 1) + (col + 1);
            if (row === rows) {
                // sum = model[row][col];
                sum = sum + model[row][col];
            }
        }
    }
    return sum;
};

export let setPlayer = (p: number) => {
    player = p;
};

main();