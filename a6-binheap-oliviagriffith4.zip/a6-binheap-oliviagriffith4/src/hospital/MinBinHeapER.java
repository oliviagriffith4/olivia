package hospital;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class MinBinHeapER  <V, P extends Comparable<P>> implements BinaryHeap<V, P> {

    private List<Prioritized<V,P>> _heap;
    /**
     * Constructor that creates an empty heap of hospital.Prioritized objects.
     */
    public MinBinHeapER() {
        _heap = new ArrayList<>();
    }

    /**
     * Constructor that builds a heap given an initial array of hospital.Prioritized objects.
     */
    // TODO: overloaded constructor
    public MinBinHeapER(Prioritized<V, P>[] initialEntries ) {
        _heap = new ArrayList<Prioritized<V,P>>();
        int n = initialEntries.length;
        int startIdx = (n / 2) - 1;

        // Perform reverse level order traversal
        // from last non-leaf node and heapify
        // each node
        for (int j =0; j < initialEntries.length; j++ ) {
            // System.out.println(initialEntries[j]);
            _heap.add(initialEntries[j]);
        }
        for (int i = startIdx; i >= 0; i--) {
            heapify(n, i);
        }
    }

    // Inserts a new element to min heap
    private void insert(Patient<V,P> addpatient)
    {

        _heap.add(addpatient);
        // Heap[++size] = element;

        // Traverse up and fix violated property
        int current = _heap.size() - 1;
        int parentpos = parent(current);
        while ((Integer)_heap.get(current).getPriority() < (Integer) _heap.get(parentpos).getPriority()) {
            swap(current, parentpos);
            current = parentpos;
            parentpos = parent(current);
            //  }

        } //else
          //  return;

    }
    // Returns position of parent
    private int parent(int pos)
    {
        return (pos - 1) / 2;
    }
    private void swap(int fpos, int spos)
    {
        Prioritized<V,P> tmp;
        tmp = _heap.get(fpos);
        _heap.set(fpos, _heap.get(spos));
        _heap.set(spos, tmp);
    }


    private void heapify(int n, int i)
    {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2
        // If left child is larger than root
        if (l < n && (Integer) _heap.get(l).getPriority() < (Integer) _heap.get(largest).getPriority())
            largest = l;

        // If right child is larger than largest so far
        if (r < n && (Integer) _heap.get(r).getPriority() < (Integer) _heap.get(largest).getPriority())
            largest = r;

        // If largest is not root
        if (largest != i) {
            swap(largest,i);
            // Prioritized<V, P> swap = _heap.get(i);
            // swap _heap.get(i) = _heap.get(largest);
            // initialEntries[largest] = swap;

            // Recursively heapify the affected sub-tree
            heapify(n, largest);
        }
    }



    @Override
    public int size() {
        return _heap.size();
    }

    // TODO: enqueue
    @Override
    public void enqueue(V value, P priority) {
        Patient <V,P> newpatient = new Patient<V,P>(value, priority);
        insert(newpatient);
    }

    // TODO: enqueue
    public void enqueue(V value) {
        Patient <V,P> newpatient = new Patient<V,P>(value);
        insert(newpatient);
    }

    // TODO: dequeue
    @Override
    public V dequeue() {
       // Patient<V,P> firstpatient = (Patient<V, P>) _heap.get(0);
        if (_heap.isEmpty() == true) {
            return null;
        } else {
            Patient<V,P> firstpatient = (Patient<V, P>) _heap.get(0);
            _heap.set(0, _heap.get(_heap.size()-1));
            _heap.remove(_heap.size()-1);
            heapify(_heap.size(), 0);
            return firstpatient.getValue();
        }
    }

    // TODO: getMin
    @Override
    public V getMin() {
        if (_heap.isEmpty() == true) {
            return null;
        } else {

            return _heap.get(0).getValue();
        }
    }


    @Override
    public Prioritized<V, P>[] getAsArray() {
        Prioritized<V,P>[] result = (Prioritized<V, P>[]) Array.newInstance(Prioritized.class, size());
        return _heap.toArray(result);
    }






}