package hospital;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        // 4, 1, 8, 50,-1, 6, 27, -12
      //  MinBinHeapER<String,Integer> heap = new MinBinHeapER<String,Integer>();
    //    heap.enqueue("olivia", 4);
     //  heap.enqueue("olivia2", 1);
    //  heap.enqueue("olivia3", 8);
    //   heap.enqueue("olivia4", 50);
      //  heap.enqueue("olivia4", -1);
     //   heap.enqueue("olivia4", 6);
    //    heap.enqueue("olivia4", 27);
    //   heap.enqueue("olivia4", -12);
     //   heap.dequeue();
     //   heap.dequeue();

        /*
        Part 1
         */
        SimpleEmergencyRoom addPatients = new SimpleEmergencyRoom();
        fillER(addPatients);
        long starttime = System.nanoTime();
        for (int i = 0; i < 10; i++) {
            Patient result = addPatients.dequeue();
        }
        long endtime = System.nanoTime();
        long average = (endtime - starttime) / 10;
        PrintWriter data = new PrintWriter("data.txt");
        data.println("SimpleEmergencyRoom average time:" + average);
        // data.close();
        // writing the start time and end time and average for the SimpleEmergencyRoom()
       /*
        Part 2
         */
        // pro 4, 1, 8, 50,-1, 6, 27, -12

        MinBinHeapER addPatients2 = new MinBinHeapER(makePatients());
        fillER(addPatients2);
        long stime = System.nanoTime();
        for (int i = 0; i < 10; i++) {
            Patient result = addPatients.dequeue();
        }
        long etime = System.nanoTime();
        long averagetime = (etime - stime) / 10;
        PrintWriter data2 = new PrintWriter("data.txt");
        data.println("MinBinHeapER average time:" + averagetime);
        long percentdecrease = (averagetime - average) / average;
        data.println("Percent decrease:" + percentdecrease);
        data.close();




        /*
        Part 3
         */
       MinBinHeapER transfer = new MinBinHeapER(makePatients());
       Prioritized[] arr = transfer.getAsArray();
       for(int i = 0; i < transfer.size(); i++) {
          System.out.println("Value: " + arr[i].getValue()
                  + ", Priority: " + arr[i].getPriority());
        }

    }

    public static void fillER(MinBinHeapER complexER) {
        for(int i = 0; i < 10000; i++) {
            complexER.enqueue(i);
          //   System.out.println(complexER.size());
        }
    }
    public static void fillER(SimpleEmergencyRoom simpleER) {
        for(int i = 0; i < 10000; i++) {
            simpleER.addPatient(i);
        }
    }

    public static Patient[] makePatients() {
        Patient[] patients = new Patient[10];
        for(int i = 0; i < 10; i++) {
            patients[i] = new Patient(i);
        }
        return patients;
    }



}



