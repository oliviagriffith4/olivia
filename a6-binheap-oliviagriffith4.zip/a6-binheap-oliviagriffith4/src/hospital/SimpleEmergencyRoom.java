package hospital;

import java.util.ArrayList;
import java.util.List;

public class SimpleEmergencyRoom {
    private List<Patient> patients;

    public SimpleEmergencyRoom() {
        patients = new ArrayList<>();
        // patients = [4, 1, 8, 50,-1, 6, 27, -12];
    }

    // TODO: dequeue
    // Fill in the dequeue method to find the patient with the
    // smallest priority using a For-each loop. Return that patient
    // and remove them from the list.


    public Patient dequeue() {
        if (size() == 0) {
            throw new UnsupportedOperationException();
        }
        int idx = find_min_idx();
        Patient result = patients.get(idx);
        patients.remove(idx);
        // _priorit.remove(idx);

        return result;
    }


    public <V, P> void addPatient(V value, P priority) {
        Patient patient = new Patient(value, (Integer) priority);
        patients.add(patient);
    }

    public <V> void addPatient(V value) {
        Patient patient = new Patient(value);
        patients.add(patient);
    }

    public List getPatients() {
        return patients;
    }

    public int size() {
        return patients.size();
    }
    public int find_min_idx() {
        if (size() == 0) {
            throw new UnsupportedOperationException();
        }
        int min_idx = 0;
        Patient min = patients.get(min_idx);

        for (int i=1; i<patients.size(); i++) {
            int patientPriority = (int) patients.get(i).getPriority();
            int minpatientPriority = (int) min.getPriority();
            if (patientPriority < minpatientPriority) {
                min_idx = i;
                min = patients.get(i);
            }
        }
        return min_idx;
    }
}

