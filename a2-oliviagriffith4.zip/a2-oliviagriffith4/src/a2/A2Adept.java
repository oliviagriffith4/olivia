package a2;

import java.util.Scanner;

public class A2Adept {
	static item[] items;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int count = scan.nextInt();// the amount of ingredients
		// item[] items;
		items = new item[count];
// it goes through the ingredients
		for (int i = 0; i < count; i++) {
			items[i] = readEntryFromScanner(scan);

		}
		int numberofrecipes = scan.nextInt();
		// System.out.println(numberofrecipes);
		Menu [] Menus = new Menu[numberofrecipes];
		for (int t = 0; t < numberofrecipes; t++) {
			Menus[t] = readMenuFromScanner(scan);
		}
		for (int i = 0; i < numberofrecipes; i++) {
			String Sumofprice = String.format("%.2f", Sumofprice(Menus[i]) );
			// String smallesstring = String.format("%.2f", biggest.name);
			int SumofCalories = ((int) (Sumofcalories(Menus[i]) + 0.5));
			System.out.println(Menus[i].menu_item_name + ":");
			System.out.println(SumofCalories + " calories");
			System.out.println("$" + Sumofprice);
			if (VeggieorNot(Menus[i]))
			System.out.println("Vegetarian");
			else {
				System.out.println("Non-Vegetarian");
			}

		}
	}
	static item readEntryFromScanner (Scanner scan){
		item e = new item();

		e.name = scan.next();
		e.price = scan.nextDouble();
		e.veggie = scan.nextBoolean();
		e.calories = scan.nextInt();
		e.ratio = e.calories / e.price;

		return e;
	}
	static Menu readMenuFromScanner (Scanner scan) {
		Menu e = new Menu();

		e.menu_item_name = scan.next();
		int amountofingredients = scan.nextInt();
		e.MenuItems = new MenuItem[amountofingredients];
		// System.out.println(e.MenuItems.length);
		for(int i = 0; i < amountofingredients; i++) {
			e.MenuItems[i] = new MenuItem();
			e.MenuItems[i].name = scan.next();
			e.MenuItems[i].NumberofOz = scan.nextDouble();
		}
		return e;
	}
	static double Sumofcalories (Menu menu_item) {
		double sum = 0;
		for (int i = 0; i < menu_item.MenuItems.length; i++) {
			String nameofitem = menu_item.MenuItems[i].name;
			double numbercalories = NumberofCalories(nameofitem);
			// System.out.println(menu_item.MenuItems[i].NumberofOz);
			sum += numbercalories * menu_item.MenuItems[i].NumberofOz;
		}
		return sum;
	}

	static double NumberofCalories (String ingredient) {
		for (int i = 0; i < items.length; i++) {
			if(items[i].name.equals(ingredient)) {
				return items[i].calories;
			}
		}
		return 0;
	}
	static double Priceofitem (String ingredient) {
		for (int i = 0; i < items.length; i++) {
			if (items[i].name.equals(ingredient)) {
				return items[i].price;
			}
		}
		return 0;
	}
	static double Sumofprice (Menu menu_item) {
		double sum = 0;
		for (int i = 0; i < menu_item.MenuItems.length; i++) {
			String nameofitem = menu_item.MenuItems[i].name;
			double numberprice = Priceofitem(nameofitem);
			sum += numberprice * menu_item.MenuItems[i].NumberofOz;
		}
		return sum;
	}
	static boolean VeggieorNot (Menu menu_item) {
		for (int i = 0; i < menu_item.MenuItems.length; i++) {
			String nameofitem = menu_item.MenuItems[i].name;
			boolean ifveggie = VeggieorNot(nameofitem);
			if(ifveggie == false) {
				return false;
			}
		}
		return true;
	}
	static boolean VeggieorNot (String ingredient) {
		for (int i = 0; i < items.length; i++) {
			if (items[i].name.equals(ingredient)) {
				return items[i].veggie;
			}
		}
		return false;
	}


	private static class Menu {
		String menu_item_name;
		MenuItem[] MenuItems;
	}
	private static class MenuItem {
		String name;
		double NumberofOz;
	}
	private static class item {
		String name;
		double price;
		boolean veggie;
		double calories;
		double ratio;
	}
	
}
