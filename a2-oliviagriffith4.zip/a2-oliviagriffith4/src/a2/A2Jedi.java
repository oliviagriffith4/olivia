package a2;

import java.util.ArrayList;
import java.util.Scanner;

public class A2Jedi {
	static item[] items;
	static Menu[] Menus;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int count = scan.nextInt();// the amount of ingredients
		items = new item[count];

// it goes through the ingredients
		for (int i = 0; i < count; i++) {
			items[i] = readEntryFromScanner(scan);

		}
		int numberofrecipes = scan.nextInt();
		// System.out.println(numberofrecipes);
		Menus = new Menu[numberofrecipes];
		for (int t = 0; t < numberofrecipes; t++) {
			Menus[t] = readMenuFromScanner(scan);
		}
		String Order = scan.next();
		ArrayList < MenuItem > amountofitems = new ArrayList  < MenuItem > ();
		theamountofitems(items, amountofitems);
		while (!Order.equals("EndOrder")) {
		// while (scan.hasNext()) {
			// System.out.println(Order);
			NumberofOrder(Order, amountofitems);
			Order = scan.next();
			// System.out.println("next order " + Order);
		}
		System.out.println("The order will require:");
		for (int i = 0; i < amountofitems.size(); i++ ) {
			String amountofoz = String.format("%.2f", amountofitems.get(i).NumberofOz );
			System.out.println(amountofoz + " ounces of " +amountofitems.get(i).name);
		}

	}
	static item readEntryFromScanner (Scanner scan){
		item e = new item();

		e.name = scan.next();
		e.price = scan.nextDouble();
		e.veggie = scan.nextBoolean();
		e.calories = scan.nextInt();
		e.ratio = e.calories / e.price;

		return e;
	}
	static void NumberofOrder (String Order, ArrayList < MenuItem > amountofitems) {
		for ( int i = 0; i < Menus.length; i++) {
			if (Order.equals(Menus[i].menu_item_name)) {
				// System.out.println(Order);
				for (int t = 0; t < Menus[i].MenuItems.length; t++) {
					TypeofMenuItems(Menus[i].MenuItems[t], amountofitems);
				}
			}
		}
		// System.out.println(" leaving number of order");
	}
	static void TypeofMenuItems (MenuItem menuitem, ArrayList < MenuItem > amountofitems) {
		for (int i = 0; i < amountofitems.size(); i++) {
			if (menuitem.name.equals(amountofitems.get(i).name)) {
				// System.out.println("found " + amountofitems.get(i).name);
				amountofitems.get(i).NumberofOz += menuitem.NumberofOz;
				// System.out.println(" leaving type of menu items");
				return;
			}

		}
		// System.out.println("not found " + menuitem.name);
		MenuItem food = new MenuItem();
		food.name = menuitem.name;
		food.NumberofOz = menuitem.NumberofOz;
		amountofitems.add(food);
		// System.out.println(" leaving type of menu items");
	}
	static void theamountofitems (item[] items, ArrayList < MenuItem > amountofitems) {
		for (int i = 0; i < items.length; i++) {
			MenuItem food = new MenuItem();
			food.name = items[i].name;
			food.NumberofOz = 0;
			amountofitems.add(food);
		}
	}
	static Menu readMenuFromScanner (Scanner scan) {
		Menu e = new Menu();

		e.menu_item_name = scan.next();
		int amountofingredients = scan.nextInt();
		e.MenuItems = new MenuItem[amountofingredients];
		// System.out.println(e.MenuItems.length);
		for(int i = 0; i < amountofingredients; i++) {
			e.MenuItems[i] = new MenuItem();
			e.MenuItems[i].name = scan.next();
			e.MenuItems[i].NumberofOz = scan.nextDouble();
		}
		return e;
	}





	private static class Menu {
		String menu_item_name;
		MenuItem[] MenuItems;
	}
	private static class MenuItem {
		String name;
		double NumberofOz;
	}
	private static class item {
		String name;
		double price;
		boolean veggie;
		double calories;
		double ratio;
	}

}


