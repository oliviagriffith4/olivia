package a2;

import java.util.List;
import java.util.Scanner;

public class A2Novice {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		int count = scan.nextInt(); // the amount of ingredients
		item[] items = new item[count];
		item lowest = new item();
		item highest = new item();
		lowest.calories = -1;
		highest.calories = -1;


		for (int i = 0; i < count; i++) {
			items[i] = readEntryFromScanner(scan);
			if ((highest.calories == -1) || (items[i].ratio >= highest.ratio)) {
				highest = items[i];
			}
			if ((lowest.calories == -1) || (items[i].ratio <= lowest.ratio)) {
				lowest = items[i];
			}
		}
		int NumberVeggies = numberofveggies(items);
		scan.close();


			// String biggeststring = String.format("%.2f", biggest.name);
			// String smallesstring = String.format("%.2f", biggest.name);
			System.out.println("Number of vegetarian ingredients: " + NumberVeggies);
			System.out.println("Highest cals/$: " + highest.name);
			System.out.println("Lowest cals/$: " + lowest.name);

		}


	private static int numberofveggies(item[] items) {
		int Veggies = 0;
		for (int i = 0; i < items.length; i++) {
			if (items[i].veggie == true) {
				Veggies++;
			}
		}
		return Veggies;
	}




		static item readEntryFromScanner (Scanner scan){
			item e = new item();

			e.name = scan.next();
			e.price = scan.nextDouble();
			e.veggie = scan.nextBoolean();
			e.calories = scan.nextInt();
			e.ratio = e.calories / e.price;

			return e;
		}

		private static class item {
			String name;
			double price;
			boolean veggie;
			int calories;
			double ratio;
		}
	}
