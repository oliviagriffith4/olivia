package a7;

public class Main {
    public static void main(String[] args) {
        // Create a new empty tree.
        SelfBalancingBST<Integer> avl_bst = new AVLTree<Integer>();
        SelfBalancingBST<Integer> avl_bst2 = new AVLTree<Integer>();

      /* avl_bst = avl_bst.insert(20);
        System.out.println(avl_bst.height());
        System.out.println(avl_bst.size());
        System.out.println(avl_bst.toString());
       avl_bst = avl_bst.insert(11);

        System.out.println(avl_bst.height());
        System.out.println(avl_bst.size());
        System.out.println(avl_bst.toString());

        avl_bst = avl_bst.insert(50);
        System.out.println(avl_bst.height());
        System.out.println(avl_bst.size());
        System.out.println(avl_bst.toString());
        avl_bst = avl_bst.insert(4);
        System.out.println(avl_bst.height());
        System.out.println(avl_bst.size());
        System.out.println(avl_bst.toString());

        avl_bst = avl_bst.insert(6);
        System.out.println(avl_bst.height());
        System.out.println(avl_bst.size());
      */
        // 0,11, 50, 4, 6, 15, 3, 16, 17
        avl_bst = avl_bst.insert(20);
        avl_bst = avl_bst.insert(11);
        avl_bst = avl_bst.insert(50);
      avl_bst = avl_bst.insert(4);
       avl_bst = avl_bst.insert(6);
       avl_bst = avl_bst.insert(15);
      avl_bst = avl_bst.insert(3);
        avl_bst = avl_bst.insert(16);
     avl_bst = avl_bst.insert(17);
      // avl_bst = avl_bst.insert(10);
        System.out.println(avl_bst.toString());

    }
}
