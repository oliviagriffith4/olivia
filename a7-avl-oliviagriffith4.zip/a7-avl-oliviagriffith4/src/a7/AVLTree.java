
package a7;


public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    // Put your fields here.

    AVLTree<T> leftChild;
    AVLTree<T> rightChild;
    T value;



    //You must at least provide a
    // constructor that takes no arguments and creates an empty AVLTree. You
    // can either use a null element value to indicate that a tree is empty or
    // explicitly keep track of whether a tree is empty with a boolean field.
    // You can assume that null is not otherwise a valid value for inserting
    // into a tree as an element.

    public AVLTree() {

        leftChild = null;
        rightChild = null;
        value = null;



        // You code for constructor here.
    }

    public AVLTree(T element) {
        //root = this;
        leftChild = new AVLTree<T>();
        rightChild = new AVLTree<T>();;
        value = element;


        // You code for constructor here.
    }


    public AVLTree<T> getleftChild() {
        return leftChild;
    }

    public AVLTree<T> getRightChild() {
        return rightChild;
    }


    /**
     * Rotates the tree left and returns
     * AVLTree root for rotated result.
     */

    int max(int a, int b) {
        return (a > b) ? a : b;
    }

    private AVLTree<T> rotateLeft() {
        AVLTree<T> oldLeftChild = leftChild;
        AVLTree<T> oldRightChild = rightChild;
        T oldValue = value;
        AVLTree<T> grandChild = oldRightChild.getleftChild();
        value = oldRightChild.getValue();
        leftChild = new AVLTree<T>(oldValue);
        leftChild.setLeft(oldLeftChild);
        leftChild.setRight(grandChild);
        rightChild = oldRightChild.getRightChild();

        /*AVLTree<T> thisRightChild = getRightChild();
        AVLTree<T> T2 = thisRightChild.getleftChild();
        AVLTree<T> oldRoot = root;
        oldRoot.setRight(T2);
        root = thisRightChild;
        root.leftChild =oldRoot;
        this.rightChild = root.rightChild;
        this.leftChild = root.leftChild;


        // Perform rotation
       /* thisRightChild.setLeft(root);
        this.setRight(T2);

        // root = y;
        if (this.getLeft() == root || this.getRight() == root) {
            System.out.println("this tree is its own child");
        }
        if (this.getleftChild() == root || this.getRightChild() == root) {
            System.out.println("this tree is its own child");
        }
       // y.leftChild.height =y.leftChild.height -1;
       */ return this;
    }

    /**
     * Rotates the tree right and returns
     * AVLTree root for rotated result.
     */
    int height(AVLTree N) {
        if (N == null)
            return -1;

        return N.height();
    }

    // A utility function to get maximum of two integers

    private AVLTree<T> rotateRight() {
        AVLTree<T> oldLeft = leftChild;
        AVLTree<T> oldRight = rightChild;
        AVLTree<T> grandChild = oldLeft.getRightChild();
        T oldValue = value;
        value = oldLeft.getValue();
        rightChild = new AVLTree<T>(oldValue);
        rightChild.setRight(oldRight);
        rightChild.setLeft(grandChild);
        leftChild = oldLeft.getleftChild();
       // root = x;
       // root.rightChild = oldRoot;
      //  oldRoot.leftChild = T2;
        //  x.setRight(root);
        // root.setLeft(T2);
        // root = x;

        // root.rightChild.findHeightSize();
        //  root.leftChild.findHeightSize();

        // root.size = root.size -1;
        // x.rightChild.height = x.rightChild.height -1;
        return this;

    }


    // Your code for public methods here.

    /**
     * Returns true if the tree is empty
     */
    public boolean isEmpty() {
        return value == null;
    }

    /**
     * Returns height of the tree.
     * <p>
     * /**
     * Returns the number of elements in the tree.
     *
     * @return the number of elements in the tree
     */
    public int height() {
        if(isEmpty()) {
            return 0;
        } else {
            // System.out.println("calulating height at subtree" + this);
            return 1 + max(getleftChild().height(),getRightChild().height());
        }
    }

    /**
     * Returns the height of the subtree.
     *
     * @param // the subtree
     * @return the height of the subtree.
     */


    public int size() {
        if(isEmpty()) {
            return 0;
        } else {
            // System.out.println("calulating height at subtree" + this);
            return 1 + getleftChild().size() + getRightChild().size();
        }
    }

    /**
     * Returns the number of nodes in the subtree.
     *
     * @param x the subtree
     *
     * @return the number of nodes in the subtree
     */


    /**
     * Inserts element into tree and returns resulting
     * tree after insertion. Depending on implementation,
     * this may or may not be the same object that you
     * started with.
     *
     * @param // to be added to the tree
     * @return resulting tree after insertion
     **/
    int getBalance() {
        if (isEmpty())
            return 0;
        return leftChild.height() - rightChild.height();
    }

    public static <T extends Number> double add(T x, T y) {
        double sum;
        sum = x.doubleValue() + y.doubleValue();
        return sum;
    }

    private void findHeightSize() {
       /* if ( root == null) {
            return;
        }
        if ( root.rightChild != null && root.leftChild != null && !root.rightChild.isEmpty() && !root.leftChild.isEmpty() ) {
            root.height = 1 + max(root.leftChild.height, root.rightChild.height);
            root.size = root.leftChild.size() + root.rightChild.size() + 1;
        } else if (root.rightChild.isEmpty() || !root.leftChild.isEmpty()) {
            root.height = 1 + root.leftChild.height;
            root.size = root.leftChild.size() + 1;
        } else if (!root.rightChild.isEmpty() || root.leftChild.isEmpty()) {
            root.height = 1 + root.rightChild.height;
            root.size = root.rightChild.size() + 1;
        } else {
            root.height = 1;
            root.size = 1;
       }*/
    }

private boolean lessThan(T value1, T value2) {
    return value1.compareTo(value2) < 0;
}

    public SelfBalancingBST<T> insert(T element) {
        int swapDirection = 0;
        if (isEmpty()) {
            value = element;
            leftChild = new AVLTree<T>();
            rightChild =new AVLTree<T>();
        } else {
            // size ++;
            // size = leftChild.size() + rightChild.size() + 1;
            if (element.compareTo(getValue()) <= 0) {
                leftChild = (AVLTree<T>) leftChild.insert(element);
                swapDirection = -1;
            } else if (element.compareTo(getValue()) >= 0)
                rightChild = (AVLTree<T>) rightChild.insert(element);
                swapDirection = 1;
            // this.height = 1 + max(leftChild.height, rightChild.height);
            //   size = leftChild.size() + rightChild.size() + 1;
        }
        // findHeightSize();

        int balance = getBalance();
        if(balance < -1){
            if(this.rightChild.getBalance() > 0){
                rightChild = rightChild.rotateRight();
                rotateLeft();
            } else {
                rotateLeft();
            }
        } else if (balance > 1){
            if(this.leftChild.getBalance() < 0){
                leftChild = leftChild.rotateLeft();
                rotateRight();
            } else {
                rotateRight();
            }

        }
        // = leftChild.size() + rightChild.size() + 1;
       /* if (balance > 1 && element.compareTo(leftChild.getValue()) < 0) {
            System.out.println("rotate right at " + getValue());
            rotateRight();

        } else if
        (balance < -1 && element.compareTo(rightChild.getValue()) > 0) {
            System.out.println("rotate left at " + getValue());
            rotateLeft();

        } else if (balance > 1 && element.compareTo(leftChild.getValue()) > 0) {
            System.out.println("rotate left then right at " + getValue());
            System.out.println(this);
            leftChild = leftChild.rotateLeft();
            System.out.println(this);
            rotateRight();
            System.out.println(this);

        } else if (balance < -1 && element.compareTo(rightChild.getValue()) < 0) {
            System.out.println("rotate right then left at " + getValue());
            rightChild = rightChild.rotateRight();
            rotateLeft();

        }*/
        return this;
    }
    /* AVLTree<T> currentNode = this;
        while (element.compareTo(currentNode.value) < 0) {
            AVLTree<T> insertNode = null;
            // currentNode.getValue().compareTo(element);
            int comparison = element.compareTo(currentNode.value);
            if (comparison < 0) {
                insertNode = currentNode.leftChild;
            } else if (comparison > 0) {
                insertNode = currentNode.rightChild;
            } else {
                return this;
            }
            if (insertNode != null) {
                currentNode = insertNode;
            } else {
                AVLTree<T> newNode = new AVLTree<T>(element);
                if (comparison < 0) {
                    currentNode = newNode;
                } else if (comparison > 0) {
                    currentNode.setRight(newNode);
                }
            }
        }
        return this;
    } */


    /**
     * Removes element from tree and returns resulting
     * tree after removal. Depending on implementation,
     * this may or may not be the same object that you
     * started with. If element is not in the tree, the
     * tree should remain unchanged and return itself.
     * *
     *
     * @param //element to be removed from the tree
     * @return resulting tree after removal
     **/
    AVLTree minValueNode(AVLTree node) {
        AVLTree current = node;

        /* loop down to find the leftmost leaf */
        while (current.leftChild != null)
            current = current.leftChild;

        return current;
    }

    public SelfBalancingBST<T> remove(T element) {
        if (isEmpty() == true) {
            return this;
        } else {
            // size ++;
            // size = leftChild.size() + rightChild.size()) - 1;

            if (element.compareTo(getValue()) > 0) {
                rightChild = (AVLTree<T>) rightChild.remove(element);
            } else if (element.compareTo(getValue()) < 0) {
                leftChild = (AVLTree<T>) leftChild.remove(element);
            } else if (element.compareTo(getValue()) == 0) {
                if ((leftChild.isEmpty()) && (rightChild.isEmpty())) {
                    return new AVLTree<T>();
                }
                if (leftChild.isEmpty()) {
                    return rightChild;
                }
                if (rightChild.isEmpty()) {
                    return leftChild;
                }
                if ((!leftChild.isEmpty()) && (!rightChild.isEmpty())) {
                    value = rightChild.findMin();
                    // this.value = leftChild.fin;
                    rightChild = (AVLTree<T>) rightChild.remove(value);
                }
            }

            // STEP 3: GET THE BALANCE FACTOR OF THIS NODE (to check whether
            // this node became unbalanced)
            int balance = getBalance();

            // If this node becomes unbalanced, then there are 4 cases
            // Left Left Case
            if (balance > 1 && leftChild.getBalance() >= 0)
                return rotateRight();

            // Left Right Case
            if (balance > 1 && leftChild.getBalance() < 0) {
                leftChild = rotateLeft();
                return rotateRight();
            }

            // Right Right Case
            if (balance < -1 && rightChild.getBalance() <= 0)
                return rotateLeft();
            // Right Left Case
            if (balance < -1 && rightChild.getBalance() > 0) {
                rightChild = rotateRight();
                return rotateLeft();
            }

            return this;
        }
    }

    /**
     * Returns the smallest value in the tree.
     * Throws a RuntimeException if called on an empty tree.
     *
     * @return the smallest value in the tree
     */
    public T findMin() {
        if (isEmpty() == true) {
            throw new RuntimeException("no elements");
        }
        AVLTree<T> currentNode = this;
        while (!currentNode.leftChild.isEmpty()) {
            currentNode = currentNode.leftChild;
        }
        return currentNode.getValue();

    }

    /**
     * Returns the largest value in the tree.
     * Throws a RuntimeException if called on an empty tree.
     *
     * @return the smallest value in the tree.
     */
    public T findMax() {
        if (isEmpty() == true) {
            throw new RuntimeException("no elements");
        }
        AVLTree<T> currentNode = this;
        while (!currentNode.rightChild.isEmpty()) {
            // System.out.println(currentNode.getValue());
            currentNode = currentNode.rightChild;
        }

        return currentNode.getValue();

    }

    /**
     * Returns true if the tree contains the specified element.
     *
     * @param element whose presence in this tree is to be tested
     * @return true if this tree contains the specified element
     */
    AVLTree<T> search(AVLTree<T> root, int element) {
        if (root == null)
            return null;
        else {
            if (value == root)
                return root;
            else if (value.compareTo(getValue()) < 0)
                return search(root.leftChild, element);
            else
                return search(root.rightChild, element);
        }
    }

    public boolean contains(T element) {
        if (isEmpty() == true) {
            return false;
        }
        if (element.compareTo(getValue()) == 0) {
            return true;
        } else if (element.compareTo(getValue()) == -1) {
            return leftChild.contains(element);
        } else
            return rightChild.contains(element);
    }

    public String toString() {
        if (isEmpty() == true) {
            return "";
        } else {
            return leftChild.toString() + " " + value.toString() + " " + rightChild.toString();
        }

    }


        /* AVLTree<T> node = search(root, (Integer) element);

        if (node == null)
            return false;

        return true;
    } */

    /**
     * Returns value at the top of the tree.
     * If a tree is empty, its value is null.
     */
    public T getValue() {
        if (isEmpty() == true) {
            return null;
        } else
            return value;
    }

    /**
     * Returns the left child of the tree.
     * Throws a RuntimeException if the tree is empty.
     */
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty() == true) {
            throw new RuntimeException("no elements");
        } else {
            if (leftChild == null) {
                return new AVLTree<T>();
            } else
                return leftChild;
        }

    }

    /**
     * Returns the right child of the tree.
     * Throws a RuntimeException if the tree is empty.
     */

    public SelfBalancingBST<T> getRight() {
        if (isEmpty() == true) {
            throw new RuntimeException("no elements");
        } else {
            if (rightChild == null) {
                return new AVLTree<T>();
            } else
                return rightChild;
        }
    }


    public void setRight(AVLTree<T> right) {
        this.rightChild = right;
    }

    public void setLeft(AVLTree<T> left) {
        this.leftChild = left;
    }
}