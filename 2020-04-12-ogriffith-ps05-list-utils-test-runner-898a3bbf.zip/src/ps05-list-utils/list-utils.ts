/**    
 * Author: Olivia Griffith    
 * ONYEN: livg   
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received   
 * or given in the completion of this work. I certify that I understand and 
 * could now rewrite on my own, without assistance from course staff,  
 * the problem set code I am submitting.
 */

import { Node, cons, first, rest, listify } from "introcs/list";
import { print } from "introcs";

export let last = <T>(list: Node<T>): T => {
    if (list === null) {
        return null;
    }

    if (!list.next) {
        return list.value;
    } else {
        return last(list.next);

    }



};

export let valueAt = <T>(list: Node<T>, index: number): T => {
    if (list === null) {
        return null;
    }

    if (index === 0) {
        return list.value;
    } else {
        return valueAt(list.next, index - 1);

    }



};


export let max = (list: Node<number>, record: number): number => {
    if (list === null) {
        return record;
    }

    if (list.next === null) {
        return Math.max(record, list.value);
    } else {
        const newmax = Math.max(record, list.value);
        return max(list.next, newmax);

    }



};

export let all = <T>(list: Node<T>, value: T): boolean => {
    if (list === null) {
        return true;
    }
    const pass = value === list.value;
    if (!pass) {
        return false;
    } else {
        return all(list.next, value);

    }



};
export let equals = <T>(a: Node<T>, b: Node<T>): boolean => {
    if (a === null && b === null) {
        return true;
    } else if (a !== null && b === null) {
        return false;
    } else if (b !== null && a === null) {
        return false;
    } else {
        if (a.value !== b.value) {
            return false;
        } else {
            return equals(a.next, b.next);
        }
    }
};



export let scale = (list: Node<number>, factor: number): Node<number> => {
    if (list === null) {
        return null;
    }

    if (!list.next) {
        return cons(list.value * factor, null);
    } else {
        return cons(list.value * factor, scale(list.next, factor));

    }



};


// Part 7. arrayToList

export let arrayToList = <T>(array: T[], index: number): Node<T> => {
    if (array.length === 0) {
        return null;
    }

    if (array.length - 1 === index) {
        return cons(array[index], null);
    } else {
        return cons(array[index], arrayToList(array, index + 1));

    }



};

// Part 8. concat
export let concat = <T> (a: Node<T>, b: Node<T>): Node <T> => {
    if (a === null && b === null) {
        return null;
    } else if (a === null) {
        return b;
    } else if (b === null) {
        return a;
    }
    if (!a.next) {
        return cons(a.value, b);
    } else {
        return cons(a.value, concat(a.next, b));
    }
};


// Part 9. sub

export let sub = <T>(list: Node<T>, start: number, length: number): Node<T> => {
    if (list === null) {
        return null;
    }

    if (start === 0) {
        if (length === 0) {
            return null;
        } else {
            return cons(list.value, sub(list.next, 0, length - 1));
        }
    } else {
        return sub(list.next, start - 1, length);

    }
};

// Part 10. splice

export let splice = <T>(a: Node<T>, start: number, b: Node<T>): Node<T> => {
    if (a === null && b === null) {
        return null;
    } else if (a === null) {
        return b;
    } else if (b === null) {
        return a;
    }
    if (start === 0) {
        return concat(b, a);
    } else {
        return cons(a.value, splice(a.next, start - 1, b));
    }
};
