package graph;


import java.util.Map;

public class Main {

    public static void main(String[] args) {
        Graph graph = new Graph("/Users/oliviagriffith/Desktop/roadtrip.csv");
        Graph graph2 = new Graph("/Users/oliviagriffith/Desktop/roadtrip.csv");
        Map<String, Double> dijkstra =  graph.dijkstra(graph2.getVertices().get("Chapel Hill"));
        System.out.println(dijkstra);
    }

}
