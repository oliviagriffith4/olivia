package graph;


import minBinHeap.MinBinaryHeap;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Graph {
    private Map<String, Vertex> _vertices;
    private List<List<String>> _data;


    // this graph is an undirected graph
    public Graph(String fileName) {
        _vertices = new HashMap<>();
        createGraph(fileName);
    }
    public Graph() {
        _vertices = new HashMap<>();
    }

    //The calculateWeight method is where you create your algorithm using 4 factors to produce a
    // single weight for your edge. However, make sure you are not doing any illegal math operations.
    // For example if you divide a number by traffic, make sure you never pass in 0 for traffic since
    // you cannot divide by 0. You can also choose to emphasize certain factors over others.
    // For instance if your car gets really bad gas mileage, you could give distance more weight
    // as opposed to scenery. Also be sure that your weights are positive. Dijkstra's algorithm does
    // NOT work with negative values.

    public double calculateWeight(int distance, int traffic, int scenery, int attractions) {
        double baseline = 20;
        double num = baseline + traffic - scenery - attractions;
        double den = baseline;
        double ratio = num/den;
        return distance * ratio;
    }

    // The Dijkstra method in Graph.java should return a Map with they key being the name
    // of the city, and the value being the total weight that it takes to reach that
    // city from your starting point

    //Part 2 of this project is to implement Dijkstra's algorithm, using a priorty queue.
    // The package minBinHeap contains the code for a Minimum Binary Heap that you will be
    // using for your algorith (do not edit anything in that folder). The Dijkstra method
    // in Graph.java should return a Map with they key being the name of the city, and the
    // value being the total weight that it takes to reach that city from your starting point.

    public Map<String, Double> dijkstra(Vertex start) {
        MinBinaryHeap<Edge, Double> priorityQueue = new MinBinaryHeap<>();
        HashSet<Vertex> visited = new HashSet<Vertex>();
        HashSet<Vertex> notVisited = new HashSet<Vertex>();
        HashMap<Vertex,Edge> directions = new HashMap<>();
        notVisited.addAll(_vertices.values());
        visited.add(start);
        List<Edge> edges = start.getEdges();
        for (Edge edge : edges) {
            priorityQueue.enqueue(edge, edge.getWeight());
        }
        if(!notVisited.contains(start)){
            HashMap<String,Double> result = new HashMap<>();
            result.put(start.getLabel(), 0.0);
            return result;
        }
        notVisited.remove(start);
        while (priorityQueue.size() > 0 && notVisited.size() > 0){
            Edge edgeMin = priorityQueue.dequeue();
            Vertex destination = edgeMin.getDestination();
            if(visited.contains(destination)){
                continue;
            }
            visited.add(destination);
            directions.put(destination, edgeMin);
            notVisited.remove(destination);
            for (Edge e: destination.getEdges()){
                priorityQueue.enqueue(e,e.getWeight());
            }
        }
        HashMap<String,Double> shortest = new HashMap<>();
        for(Vertex v: _vertices.values()){
            shortest.put(v.getLabel(), getShortestPath(v, directions));
        }
        return shortest;
    }

    private Double getShortestPath(Vertex vertex, HashMap<Vertex, Edge> directions) {
        double totalWeight = 0.0;
        Vertex currentVertex = vertex;
        while(directions.containsKey(currentVertex)) {
            Edge edge = directions.get(currentVertex);
            Vertex source = edge.getSource();
            double weight = edge.getWeight();
            totalWeight = totalWeight + weight;
            currentVertex = source;
        }
        return totalWeight;
    }

    // Do not edit anything below

    /*
    reads through each entry in csv and calls readLine to create edges and vertices.
     */
    public void createGraph(String fileName) {
        readCSV(fileName);
        for(List<String> list: _data) {
            readLine(list.get(0), list.get(1), Integer.parseInt(list.get(2)), Integer.parseInt(list.get(3))
                    , Integer.parseInt(list.get(4)), Integer.parseInt(list.get(5)));
        }
    }
    /*
    reads through each line of csv and puts data into an ArrayList
     */
    public void readCSV(String fileName) {
        _data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String header = br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                _data.add(Arrays.asList(values));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
    converts one entry of data into vertices and edges
     */
    public void readLine(String src, String dest, int distance, int traffic, int scenery, int attractions) {
        // find source and destination nodes, if they don't exist, create them
        Vertex source = _vertices.get(src);
        if(source == null)
            source = new VertexImpl(src);
        Vertex destination = _vertices.get(dest);
        if(destination == null)
            destination = new VertexImpl(dest);

        // calculate weight of edge
        double weight = calculateWeight(distance, traffic, scenery, attractions);

        //create edge
        Edge e = new EdgeImpl(source, destination, weight);
        source.addEdge(e);

        //add reverse direction edge
        e = new EdgeImpl(destination, source, weight);
        destination.addEdge(e);

        //add to graph
        _vertices.put(src, source);
        _vertices.put(dest, destination);

    }

    public Map<String, Vertex> getVertices() {
        return _vertices;
    }
}
