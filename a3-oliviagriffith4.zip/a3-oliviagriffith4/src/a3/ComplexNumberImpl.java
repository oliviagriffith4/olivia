package a3;

public class ComplexNumberImpl implements ComplexNumber {

    // Fields go here.
    private double Real;

    private double Imaginary;
    // Constructor

    public ComplexNumberImpl(double real,double imag) {
        Real = real;
        Imaginary = imag;
    }

    // Instance methods go here.
    public double getReal() {
        return Real;
    }
    public double getImaginary() {
        return Imaginary;
    }
    public double getAbsValue() {
        return Math.sqrt(Real * Real + Imaginary * Imaginary);
    }
    public ComplexNumber multiply(ComplexNumber other){
        double newReal = (Real * other.getReal() - Imaginary * other.getImaginary());
        double newImaginary = (Real * other.getImaginary() + Imaginary * other.getReal());
        return new ComplexNumberImpl(newReal, newImaginary);
    }
    public ComplexNumber add(ComplexNumber other) {
        double newReal = (Real + other.getReal());
        double newImaginary = (Imaginary + other.getImaginary());
        return new ComplexNumberImpl(newReal, newImaginary);
    }
    public boolean equals(ComplexNumber other) {
        double first = Math.abs(Real - other.getReal());
        double second = Math.abs(Imaginary - other.getImaginary());
        if (first < ComplexNumber.EQUALS_EPSILON && second < ComplexNumber.EQUALS_EPSILON) {
            return true;
        }
        else {
            return false;
        }

    }
}
