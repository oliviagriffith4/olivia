package a3test;

// import a3.ComplexNumberImpl;
import a3.ComplexNumber;
import a3.ComplexNumberImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class A3Tests {

    // Test axiom:
    // real(create(A,B)) = ????
    @Test
    public void testReal() {
        ComplexNumber test = new ComplexNumberImpl(1.0, 2.0 );
        assertEquals(1.0, test.getReal());

    }

    // Test axiom:
    // imag(create(A,B)) = ????
    @Test
    public void testImag() {
        ComplexNumber test = new ComplexNumberImpl(1.0, 2.0 );
        assertEquals(2.0, test.getImaginary());

        // fail("Replace with testing code");
    }

    // Test axiom:
    // absolute(create(A,B)) = ????
    @Test
    public void testAbsolute() {
        // fail("Replace with testing code");

        ComplexNumber test = new ComplexNumberImpl(-2.0, 1.0);
        assertEquals(Math.sqrt(5), test.getAbsValue());
    }

    // Test axiom:
    // add(create(A,B), C) = ????
    @Test
    public void testAdd1() {
        int a = 3;
        int b = 8;
        ComplexNumber c = new ComplexNumberImpl(2, 7);
        ComplexNumber lhs = new ComplexNumberImpl(a,b).add(c);
        ComplexNumber rhs = new ComplexNumberImpl(a,b).add(c);

        assertEquals(lhs.getReal(), rhs.getReal());
        assertEquals(lhs.getImaginary(), rhs.getImaginary());
    }


    // Test axiom:
    // add(C, create(A,B)) = ????
    @Test
    public void testAdd2() {
        int a = 3;
        int b = 8;
        ComplexNumber c = new ComplexNumberImpl(2, 7);
        ComplexNumber lhs = c.add(new ComplexNumberImpl(a,b));
        ComplexNumber rhs = new ComplexNumberImpl(a,b).add(c);

        assertEquals(lhs.getReal(), rhs.getReal());
        assertEquals(lhs.getImaginary(), rhs.getImaginary());
    }

    // Test axiom:
    // multiply(create(A,B), C) = ????
    @Test
    public void testMultiply1() {
        int a = 3;
        int b = 8;
        ComplexNumber c = new ComplexNumberImpl(2, 7);

        ComplexNumber lhs = new ComplexNumberImpl(a,b).multiply(c);
        ComplexNumber rhs = new ComplexNumberImpl(a,b).multiply(c);

        assertEquals(lhs.getReal(), rhs.getReal());
        assertEquals(lhs.getImaginary(), rhs.getImaginary());
    }

    // Test axiom:
    // multiply(C, create(A,B)) = ????
    @Test
    public void testMultiply2() {
        int a = 3;
        int b = 8;
        ComplexNumber c = new ComplexNumberImpl(2, 7);

        ComplexNumber lhs = c.multiply(new ComplexNumberImpl(a, b));
        ComplexNumber rhs = new ComplexNumberImpl(a, b).multiply(c);

        assertEquals(lhs.getReal(), rhs.getReal());
        assertEquals(lhs.getImaginary(), rhs.getImaginary());
    }

    // Test axiom:
    // equals(create(A,B), C) = ????
    @Test
    public void testEquals1() {
        int a = 3;
        int b = 8;
        ComplexNumber c = new ComplexNumberImpl(2, 7);

        boolean lhs = new ComplexNumberImpl(a,b).equals(c);
        boolean rhs = new ComplexNumberImpl(a,b).equals(c);

       // assertEquals(lhs., rhs.);
        //assertEquals(lhs., rhs.);
    }

    // Test axiom:
    // equals(C, create(A,B)) = ????
    @Test
    public void testEquals2() {
        int a = 3;
        int b = 8;
        ComplexNumber c = new ComplexNumberImpl(2, 7);

        boolean lhs = c.equals(new ComplexNumberImpl(a, b));
        boolean rhs = new ComplexNumberImpl(a, b).equals(c);
     //   assertEquals();
      //  assertEquals();
    }
}
