/**  
 * Author: Olivia Griffith 
 * ONYEN: Livg 
 * UNC Honor Pledge: I certify that no unauthorized assistance has been received  
 * or given in the completion of this work. I certify that I understand and
 * could now rewrite on my own, without assistance from course staff, 
 * the problem set code I am submitting.
 */
import { print, csvToArray } from "introcs";
export class WeatherRow {
  date: string = "";
  precipitation: number = 0;
  snow: number = 0;
  tempHigh: number = 0;
  tempLow: number = 0;
  nice: number = 15;
  // above8: number = 0;
  // above9: number = 0;
}
export let main = async () => {

  let data = await csvToArray("Select fall-2016.csv", WeatherRow);


  print(data);

};

export let totalPrecipitation = (array: WeatherRow[]): number => {
  let totalPrecipitation = 0;
  for (let i = 0; i < array.length; i++) {
    totalPrecipitation = array[i].precipitation + totalPrecipitation;
  }
  return (totalPrecipitation);
};
export let snowDays = (array: WeatherRow[]): number => {
  let snowDays = 0;
  for (let i = 0; i < array.length; i++) {
    if (array[i].snow !== 0) {
      snowDays++;
    }
  }
  return (snowDays);
};
export let niceDays = (array: WeatherRow[]): number => {
  let niceDays = 0;
  for (let i = 0; i < array.length; i++) {
    if (array[i].tempHigh < 80 && array[i].tempLow > 60) {
      niceDays++;
    }
  }
  return (niceDays);
};
export let maximumTemperature = (array: WeatherRow[]): number => {
  if (array.length === 0) {
    return (0);
  }
  let temp = array[0].tempHigh;
  let max = 0; 
  for (let i = 0; i < array.length; i++) {
    if (array[i].tempHigh > temp) {
      temp = array[i].tempHigh;
      max = i;
    }
  }
  return (temp);
};

export let coldestDay = (array: WeatherRow[]): string => {
  if (array.length === 0) {
    return ("N/A");
  }
  let temp = array[0].tempLow;
  let day = 0;
  for (let i = 0; i < array.length; i++) {
    if (array[i].tempLow < temp) {
      temp = array[i].tempLow;
      day = i;
    }
  }
  return (array[day].date);
};

export let daysAbove = (array: WeatherRow[], temp: number): number => {
  let daysAbove = 0;
  for (let i = 0; i < array.length; i++) {
    if (array[i].tempHigh > temp) {
      daysAbove++;
    }
  }
  return daysAbove;
};

main();